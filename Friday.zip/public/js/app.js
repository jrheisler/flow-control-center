// js/app.js

// === Reactive header title ===
const headerTitleStream = new Stream("FCC");

// === Initial BPMN XML template ===
const diagramXMLStream = new Stream(`<?xml version="1.0" encoding="UTF-8"?>
<bpmn:definitions xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL"
                  xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI"
                  xmlns:dc="http://www.omg.org/spec/DD/20100524/DC"
                  id="Definitions_1">
  <bpmn:process id="Process_1" isExecutable="true">
    <bpmn:startEvent id="StartEvent_1"/>
  </bpmn:process>
  <bpmndi:BPMNDiagram id="BPMNDiagram_1">
    <bpmndi:BPMNPlane id="BPMNPlane_1" bpmnElement="Process_1"/>
  </bpmndi:BPMNDiagram>
</bpmn:definitions>`);


document.addEventListener('DOMContentLoaded', () => {
Object.assign(document.body.style, {
    display:      'flex',
    flexDirection:'column',
    height:       '100vh',
    margin:       '0'
  });
  // ─── pull in the UMD globals ───────────────────────────────────────────────
  const { BpmnJS }       = window;
  const layoutProcess    = window.bpmnAutoLayout?.layoutProcess;
  const NavigatorModule  = window.NavigatorModule;

  // ─── build canvas + xml-editor elements ────────────────────────────────────
  const canvasEl = document.createElement('div');
  canvasEl.id = 'canvas';
    Object.assign(canvasEl.style, {
    flex:      '1 1 auto',                    // stretch to fill remaining space
    minHeight: '600px',                       // but never shrink below 600px
    width:     '100%',
    border:    `1px solid ${currentTheme.get().colors.border}`
  });

  
  // ─── mount theme selector, spacer, canvas & xml ────────────────────────────
  document.body.appendChild(canvasEl);
  
  // ─── sanity check ───────────────────────────────────────────────────────────
  if (typeof BpmnJS !== 'function') {
    console.error("bpmn-js not found! Did you load the UMD bundle?");
    return;
  }

  // ─── instantiate modeler with navigator only ───────────────────────────────
  const navModule = window.navigatorModule || window.bpmnNavigator;

 const modeler = new BpmnJS({
   container:       canvasEl,
   keyboard:        { bindTo: window },
   selection:       { mode: 'multiple' },
  additionalModules: navModule ? [ navModule ] : []
  });
const eventBus     = modeler.get('eventBus');
const commandStack = modeler.get('commandStack');
const isDirty = new Stream(false);

// push every change into your XML Stream:
eventBus.on('commandStack.changed', async () => {
    try {
      const { xml } = await modeler.saveXML({ format: true });
      diagramXMLStream.set(xml);
      isDirty.set(true);
      console.log("72");
    } catch (err) {
      console.error('failed to save current XML:', err);
    }
});


  // ─── expose services ────────────────────────────────────────────────────────
  const moddle          = modeler.get('moddle');
  const elementFactory  = modeler.get('elementFactory');
  const modeling        = modeler.get('modeling');
  const elementRegistry = modeler.get('elementRegistry');
  const selectionService= modeler.get('selection');

  // ─── theme (page background) ────────────────────────────────────────────────
  currentTheme.subscribe(applyThemeToPage);

  // ─── hidden file-input for BPMN import ──────────────────────────────────────
  const fileInput = document.createElement('input');
  fileInput.type    = 'file';
  fileInput.accept  = '.bpmn,.xml';
  fileInput.style.display = 'none';
  fileInput.onchange = async e => {
    const file = e.target.files[0];
    if (!file) return;
    const xml = await file.text();
    diagramXMLStream.set(xml);
    await importXml(xml);
  };
  document.body.appendChild(fileInput);

  // generic funciton for nodes
  function addGeneric(type) {
    const bpmnType = 'bpmn:' + type;
    const bo        = moddle.create(bpmnType, { id:`${type}_${Date.now()}`, name:type });

    const shape     = elementFactory.createShape({ type:bpmnType, businessObject:bo });
    let parentShape;

    if (type === 'Participant') {
      parentShape = modeler.get('canvas').getRootElement();
      // also link BO into Collaboration as above…
    } else if (type === 'Lane') {
      // reuse your existing lane-creation logic to get laneSet + laneBo
      return addLane();
    } else {
      parentShape = elementRegistry.getAll().find(e => e.type === 'bpmn:Process');
    }

    modeling.createShape(shape, { x:300, y:150 }, parentShape);
  }


  // ─── import / initial render ───────────────────────────────────────────────
  async function importXml(xml) {
    try {
      await modeler.importXML(xml);
      const svg = canvasEl.querySelector('svg');
      if (svg) svg.style.height = '100%';
    } catch (err) {
      console.error("Import error:", err);
    }
  }
  importXml(diagramXMLStream.get());

  // ─── build controls bar ────────────────────────────────────────────────────

// disable the “Show XML” button until there are edits…
const saveBtn = reactiveButton(
  new Stream('💾'),
  () => { /* push to server… */ isDirty.set(false); },
  { accent: true, disabled: isDirty, title: "Save" }   // <-- pass your Stream directly!
);

// when dirty changes, enable/disable the button automatically:
isDirty.subscribe(d => {
  saveBtn.disabled = !d;
  saveBtn.style.opacity = d ? '1' : '0.5';
  saveBtn.style.cursor  = d ? 'pointer' : 'not-allowed';
});



const elementChoices = [
  // tasks
  'Task', 'UserTask', 'ManualTask', 'ReceiveTask', 'SendTask',
  'ServiceTask', 'ScriptTask', 'BusinessRuleTask', 'CallActivity',
  'SubProcess', 'Transaction',

  // gateways
  'ExclusiveGateway', 'InclusiveGateway', 'ParallelGateway',
  'ComplexGateway', 'EventBasedGateway',

  // events
  'StartEvent', 'EndEvent',
  'IntermediateThrowEvent', 'IntermediateCatchEvent',
  'BoundaryEvent',

  // data & artifacts
  'DataObject', 'DataObjectReference', 'DataStoreReference',
  'TextAnnotation', 'Group',

  // collaboration
  'MessageFlow', 'Association'
];

  const newElementTypeStream = new Stream(elementChoices[0]);
  const elementTypeDropdown = dropdownStream(
    newElementTypeStream,
    { choices: elementChoices, width: '200px', margin: '0 1rem 0 0' },
    currentTheme
  );

  const controlsBar = row([
    // 1) title
    reactiveText(headerTitleStream, { size:'1.5rem', weight:'bold', margin:'0' }),

    // 2) Import BPMN
    reactiveButton(new Stream("📂"), () => fileInput.click(),  { accent: true, title: "Import BPMN file" }),

    // 3) Show XML
   reactiveButton(
  new Stream("📄"),
  async () => {
    try {
      // 1) get the pretty‐printed XML
      const { xml } = await modeler.saveXML({ format: true });

      // 2) build a Blob and temporary URL
      const blob = new Blob([xml], { type: 'application/xml' });
      const url  = URL.createObjectURL(blob);

      // 3) programmatically click a hidden <a> to download
      const a = document.createElement('a');
      a.href        = url;
      a.download    = 'diagram.bpmn';   // or '.xml'
      document.body.appendChild(a);     // required for Firefox
      a.click();
      document.body.removeChild(a);

      // 4) clean up
      URL.revokeObjectURL(url);
      
      diagramXMLStream.set(xml);
    } catch (err) {
      console.error("Export failed:", err);
    }
  },
  {
    accent: true,
    title:  "Download BPMN XML"
  }
),


    // 4) element dropdown + Add
    elementTypeDropdown,
    // add the element in the dropdown
    reactiveButton(
      new Stream("🏊"),
      () => {
        const type = newElementTypeStream.get();
        if (type !== 'Participant') {
          return addGeneric(type);
        }        
      },
      { accent: true, title: "Add & Center Pool (Down+Right)" }
    ),


    // 5) Connect Shapes
    reactiveButton(new Stream("🔗"), () => {
      const sel = (selectionService.get()||[])
        .filter(e => e.type && e.type.startsWith('bpmn:'));
      if (sel.length !== 2) return alert("Select exactly two shapes (Ctrl+click).");

      let [ src, tgt ] = sel;
      if (src.id === tgt.id) return alert("Cannot connect a shape to itself.");
      // if StartEvent is second, swap
      if (tgt.type === 'bpmn:StartEvent' && src.type !== 'bpmn:StartEvent') {
        [ src, tgt ] = [ tgt, src ];
      }

      const flowId = `Flow_${Date.now()}`;
      const flowBo = moddle.create('bpmn:SequenceFlow', { id: flowId });
      const conn   = elementFactory.createConnection({
        type: 'bpmn:SequenceFlow', businessObject: flowBo
      });

      modeling.connect(src, tgt, conn);
    }, { accent: true, title: "Connect Nodes" }),

    // 6) Add Lane
    reactiveButton(new Stream("⛙"), () => {
      const processShape = elementRegistry.getAll()
        .find(e => e.type === 'bpmn:Process');
      if (!processShape) return alert("Draw a <bpmn:Process> first!");

      const processBo = processShape.businessObject;
      let laneSetBo = (processBo.laneSets||[])[0];
      if (!laneSetBo) {
        laneSetBo = moddle.create('bpmn:LaneSet', {
          id:`LaneSet_${Date.now()}`, lanes:[]
        });
        processBo.laneSets = [ laneSetBo ];
      }

      const idx    = (laneSetBo.lanes||[]).length + 1;
      const laneBo = moddle.create('bpmn:Lane', {
        id:`Lane_${Date.now()}`, name:`Lane ${idx}`
      });
      laneSetBo.lanes = [ ...(laneSetBo.lanes||[]), laneBo ];

      const laneShape = elementFactory.createShape({
        type: 'bpmn:Lane', businessObject: laneBo
      });
      modeling.createShape(laneShape,
        { x:100, y:50 + 100*(idx-1) },
        processShape
      );
    }, { accent: true, title: "Add Lanes" }),

    // 7) Auto-Layout (via standalone layoutProcess)
    reactiveButton(new Stream("🔧"), async () => {
      if (!layoutProcess) {
        return alert("Auto-layout library not loaded.");
      }
      try {
        const { xml } = await modeler.saveXML({ format: true });
        const laidOut = await layoutProcess(xml);
        await modeler.importXML(laidOut);
      } catch (err) {
        console.error("Auto-layout failed:", err);
      }
    }, { accent: true, title: "Auto Arrange" }),

    // 8) Zoom In/Out, Fit
    
  // ─── Continuous Zoom In ────────────────────────────────────────────────────
  reactiveButton(
    new Stream("➕"),
    () => {
      const canvas = modeler.get('canvas');
      const vb     = canvas.viewbox();                 // { x, y, width, height, scale }
      const next   = vb.scale * 1.2;                   // bump up by 20%
      canvas.zoom(next, true);                         // 'true' keeps it centered
    },
    { outline: true, title: "Zoom In" }
  ),

  // ─── Continuous Zoom Out ───────────────────────────────────────────────────
  reactiveButton(
    new Stream("➖"),
    () => {
      const canvas = modeler.get('canvas');
      const vb     = canvas.viewbox();
      const next   = vb.scale * 0.8;                   // shrink by 20%
      canvas.zoom(next, true);
    },
    { outline: true, title: "Zoom Out" }
  ),

    reactiveButton(new Stream("↔"), () => modeler.get('canvas').zoom('fit-viewport'), { outline: true, title: "Stretch" }),

    // 9) Export PNG
    reactiveButton(new Stream("📷"), async () => {
      const { svg } = await modeler.saveSVG();
      const img = new Image();
      const blob = new Blob([svg], { type: 'image/svg+xml' });
      img.src = URL.createObjectURL(blob);
      img.onload = () => {
        const c = document.createElement('canvas');
        c.width = img.width; c.height = img.height;
        c.getContext('2d').drawImage(img,0,0);
        c.toBlob(b => {
          const a = document.createElement('a');
          a.href = URL.createObjectURL(b);
          a.download = 'diagram.png';
          a.click();
        });
      };
    }, { accent: true, title: "Download as PNG" }),
    saveBtn,    
    // 10) finally theme selector
    themedThemeSelector()

  ], {
    justify: 'flex-start',
    align:   'center',
    padding: '1rem',
    bg:      currentTheme.get().colors.surface,
    wrap:    true, 
  });

  // keep background / border in sync
  currentTheme.subscribe(theme => {
    controlsBar.style.backgroundColor = theme.colors.surface;
    controlsBar.style.borderBottom    = `1px solid ${theme.colors.border}`;
  });

  // insert the controls bar before the canvas
  document.body.insertBefore(controlsBar, canvasEl);

  // ─── theme-driven CSS overrides for BPMN elements ─────────────────────────
  const bpmnThemeStyle = document.createElement('style');
  document.head.appendChild(bpmnThemeStyle);

  currentTheme.subscribe(theme => {
    const b  = theme.bpmn;
    const bg = theme.colors.background;

    bpmnThemeStyle.textContent = `
      #canvas { background: ${bg} !important; }
      .djs-element .djs-shape {
        fill: ${b.shape.fill} !important;
        stroke: ${b.shape.stroke} !important;
        stroke-width: ${b.shape.strokeWidth}px !important;
      }
      .djs-connection .djs-connection-inner,
      .djs-connection .djs-connection-outer {
        stroke: ${b.connection.stroke} !important;
        stroke-width: ${b.connection.strokeWidth}px !important;
      }
      .djs-connection .djs-marker {
        fill: ${b.marker.fill} !important;
        stroke: ${b.marker.stroke} !important;
      }
      .djs-element .djs-label {
        fill: ${b.label.fill} !important;
        font-family: ${b.label.fontFamily} !important;
      }
      .djs-connection .djs-connection-overlay,
      .djs-connection .djs-connection-preview {
        display: none !important;
      }
      .djs-element.djs-element-selected .djs-shape,
      .djs-connection.djs-connection-selected .djs-connection-outer {
        stroke: ${b.selected.stroke} !important;
        stroke-width: ${b.selected.strokeWidth}px !important;
      }
    `;
  });

});
